export const Colors = {
    white: '#FFF',
    black: '#000'
}